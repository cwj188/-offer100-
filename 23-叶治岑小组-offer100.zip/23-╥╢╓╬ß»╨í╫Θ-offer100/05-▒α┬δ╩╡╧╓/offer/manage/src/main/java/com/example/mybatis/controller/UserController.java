package com.example.mybatis.controller;

import com.example.mybatis.entity.Resume;
import com.example.mybatis.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

//@RestController
@Controller
public class UserController {

    @Autowired
    private UserMapper userMapper;
    String pw;



    @GetMapping("/123") //来到登录页面
    public String index(){
        return "user/login";
    }

    @GetMapping("/regist")  //来到注册页面
    public String Register(){
        return "user/register";
    }

    @PostMapping("/regist")  //注册成功
    public String FinishReg(Resume user){
        Integer id = user.getId();
        String password = user.getPassword();
        String name = user.getName();
        String email = user.getEmail();
        String phone = user.getPhone();
        userMapper.insertUser(id, password, name, email, phone);
        return "user/registerSuccess";
    }

    @PostMapping("/users")  //登录成功，来到用户主页面
    public String getUser(Model model, Integer id, String password){
        List<Resume> user = userMapper.getUserById(id, password);
        System.out.println("list:"+user);
        model.addAttribute("users",user);
        return "user/userPage";
    }

    @GetMapping("/users")  //登录成功，来到用户主页面
    public String getuser(Model model, Integer id, String password){
        List<Resume> user = userMapper.getUserById(id, password);
        System.out.println("list:"+user);
        model.addAttribute("users",user);
        return "user/userPage";
    }

    @GetMapping("/add/{id}")  //来到添加简历页面
    public String insertPage(@PathVariable("id") Integer id, Model model, Resume resume){
        resume = userMapper.getuserById(id);
        model.addAttribute("users", resume);
        System.out.println(resume);
        return "user/addResume";
    }

    @PostMapping("/add")  //添加成功，来到简历信息页面
    public String insertUser(Resume resume){
        System.out.println("修改后的数据：" + resume);
        int id = resume.getId();
        String name = resume.getName();
        String gander = resume.getGander();
        String email = resume.getEmail();
        String phone = resume.getPhone();
        String position = resume.getPosition();
        String content = resume.getContent();
        userMapper.updatenew(id, name, gander, email, phone, position, content);
        return "forward:/users";
    }

    @GetMapping("/update/{id}")  //来到修改简历页面
    public String updatePage(@PathVariable("id") Integer id, Model model, Resume user){
        user = userMapper.getuserById(id);
        System.out.println("要修改的数据：" + user);
        model.addAttribute("users",user);
        return "user/updateResume";
    }

    @PostMapping("/update")  //修改成功，来到简历信息页面
    public String updateUser(Resume user){
        System.out.println("修改后的数据：" + user);
        int id = user.getId();
        String name = user.getName();
        String gander = user.getGander();
        String email = user.getEmail();
        String phone = user.getPhone();
        String position = user.getPosition();
        String content = user.getContent();
        userMapper.updatenew(id, name, gander, email, phone, position, content);
        return "forward:/users";
    }


    @GetMapping("/delete/{id}")  //来到删除简历页面
    public String deletePage(@PathVariable("id") Integer id, Model model, Resume user){
        user = userMapper.getuserById(id);
        System.out.println("要删除的数据：" + user);
        model.addAttribute("users",user);
        return "user/deleteResume";
    }

    @PostMapping("/delete")  //删除成功，来到简历信息页面
    public String deleteUser(Integer id){
        userMapper.deletenew(id);
        return "forward:/users";
    }

}
