package com.example.mybatis.mapper;

import com.example.mybatis.entity.Resume;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface UserMapper {

    @Select("select * from rumber where id=#{id} AND `password`=#{password}")
    public List<Resume> getUserById(@Param("id") Integer id, @Param("password") String password);
    @Select("select * from rumber where id=#{id}")
    public Resume getuserById(@Param("id") Integer id);

    @Insert("insert into rumber(id, password, name, email, phone) value(#{id}, #{password}, #{name}, #{email}, #{phone})")
    public void insertUser(@Param("id") Integer id, @Param("password") String password, @Param("name") String name, @Param("email") String email, @Param("phone") String phone);

    @Insert("insert into rumber(name, gander, email, phone, position, content) value(#{name}, #{gander}, #{email}, #{phone}, #{position}, #{content})")
    public void insertnew(@Param("name") String name, @Param("gander") String gander, @Param("email") String email, @Param("phone") String phone, @Param("position") String position, @Param("content") String content);

    @Update("UPDATE rumber SET `name`=#{name}, gander=#{gander}, email=#{email}, phone=#{phone}, position=#{position}, content=#{content} WHERE id=#{id}")
    public void updatenew(@Param("id") int id, @Param("name") String name, @Param("gander") String gander, @Param("email") String email, @Param("phone") String phone, @Param("position") String position, @Param("content") String content);

    /*@Delete("DELETE FROM rumber WHERE id=#{id}")
    public void deletenew(String id);*/

    @Update("UPDATE rumber SET `name`='', gander='', email='', phone='', position='', content='' WHERE id=#{id}")
    public void deletenew(@Param("id") Integer id);
}
