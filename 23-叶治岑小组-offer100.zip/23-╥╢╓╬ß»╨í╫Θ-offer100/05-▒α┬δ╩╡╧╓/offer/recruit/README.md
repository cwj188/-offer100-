# IndexRecruit
**本项目测试数据均为虚构，仅用作交流学习，不用于任何商业用途**
* Spring Boot + Mybatis开发实习生招聘网站    
    * 前端Vue.js实现双向数据绑定；  
    * 后端基于用户和基于项协同过滤推荐算法职位推荐；

# 主页效果图
![homepage](https://github.com/oncestep/IndexRecruit/raw/master/img/homepage.png)
