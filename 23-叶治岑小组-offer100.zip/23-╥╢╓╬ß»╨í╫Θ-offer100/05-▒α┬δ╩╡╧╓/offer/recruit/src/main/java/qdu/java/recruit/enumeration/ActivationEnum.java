package qdu.java.recruit.enumeration;

public enum ActivationEnum {

    // 统一管理用户活跃度计算权重



}
