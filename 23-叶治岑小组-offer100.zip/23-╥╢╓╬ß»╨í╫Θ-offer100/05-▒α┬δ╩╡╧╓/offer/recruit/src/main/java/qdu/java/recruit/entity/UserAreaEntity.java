package qdu.java.recruit.entity;

public class UserAreaEntity {
    private Integer usernum;
    private String area;

    public Integer getUsernum() {
        return usernum;
    }

    public void setUsernum(Integer usernum) {
        this.usernum = usernum;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

}
