package qdu.java.recruit.entity;

public class WebCountEntity {
    private Integer companynum;
    private Integer offernum;
    private Integer usernum;
    private Integer visitnum;

    public Integer getCompanynum() {
        return companynum;
    }

    public void setCompanynum(Integer companynum) {
        this.companynum = companynum;
    }

    public Integer getOffernum() {
        return offernum;
    }

    public void setOffernum(Integer offernum) {
        this.offernum = offernum;
    }

    public Integer getUsernum() {
        return usernum;
    }

    public void setUsernum(Integer usernum) {
        this.usernum = usernum;
    }

    public Integer getVisitnum() {
        return visitnum;
    }

    public void setVisitnum(Integer visitnum) {
        this.visitnum = visitnum;
    }

}
