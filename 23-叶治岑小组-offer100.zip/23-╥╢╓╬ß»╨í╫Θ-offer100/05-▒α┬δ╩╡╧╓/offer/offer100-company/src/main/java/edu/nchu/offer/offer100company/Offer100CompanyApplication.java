package edu.nchu.offer.offer100company;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;

@SpringBootApplication
public class Offer100CompanyApplication {

    public static void main(String[] args) {
        SpringApplication.run(Offer100CompanyApplication.class, args);
    }

}
