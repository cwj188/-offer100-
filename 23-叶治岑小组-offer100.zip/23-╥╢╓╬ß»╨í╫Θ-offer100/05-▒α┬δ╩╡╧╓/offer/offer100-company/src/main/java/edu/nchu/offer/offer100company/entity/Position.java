package edu.nchu.offer.offer100company.entity;

public class Position {

    private Integer positionId;

    private String positionName;

    private String positionType;

    private String salary;

    private String positionIntro;

    private String companyName;

    public Integer getPositionId() {
        return positionId;
    }

    public void setPositionId(Integer positionId) {
        this.positionId = positionId;
    }

    public String getPositionName() {
        return positionName;
    }

    public void setPositionName(String positionName) {
        this.positionName = positionName;
    }

    public String getPositionType() {
        return positionType;
    }

    public void setPositionType(String positionType) {
        this.positionType = positionType;
    }

    public String getSalary() {
        return salary;
    }

    public void setSalary(String salary) {
        this.salary = salary;
    }

    public String getPositionIntro() {
        return positionIntro;
    }

    public void setPositionIntro(String positionIntro) {
        this.positionIntro = positionIntro;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
}
