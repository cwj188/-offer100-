package edu.nchu.offer.offer100company.controller;

import edu.nchu.offer.offer100company.entity.Position;
import edu.nchu.offer.offer100company.service.impl.PositionServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class PositionController {

    @Autowired
    private PositionServiceImpl positionService;

    @GetMapping("/positionInfo")
    public String positionInfo(Model model){
        System.out.println("341413412323");
        List<Position> positionList = null;
        positionList = positionService.findAllPosition();
        model.addAttribute("positionList", positionList);
        return "positionInfo";
    }

    @GetMapping("/releasePosition")
    public String release(){
        return "releasePosition";
    }

    @PostMapping("/releasePosition")
    public String releasePosition(String positionID, String positionName, String positionType, String salary, String positionIntro, String companyName){
        int positionId = Integer.valueOf(positionID);
        this.positionService.addPosition(positionId, positionName, positionType, salary, positionIntro, companyName);
        return "positionInfo";
    }

}
