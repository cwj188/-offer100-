package edu.nchu.offer.offer100company.dao;

import edu.nchu.offer.offer100company.entity.Company;
import org.apache.ibatis.annotations.*;

@Mapper
public interface CompanyMapper {

    @Insert("insert into companyinfo(companyId, companyName, companyPassword, companyEmail, companySize, companyIntro, companyPlace) values(#{companyId}, #{companyName}, #{companyPassword}, #{companyEmail}, #{companySize}, #{companyIntro}, #{companyPlace})")
    void insertCompany(@Param("companyId")String companyId, @Param("companyName")String companyName, @Param("companyPassword")String companyPassword, @Param("companyEmail")String companyEmail, @Param("companySize")String companySize, @Param("companyIntro")String companyIntro, @Param("companyPlace")String companyPlace);

    @Select("select * from companyinfo where companyId = #{companyId}")
    public Company selectCompanyById(@Param("companyId") String companyId);

    @Update("update companyinfo set companyName = #{companyName}, companyPassword = #{companyPassword}, companyEmail = #{companyEmail}, companySize = #{companySize}, companyIntro = #{companyIntro}, companyPlace = #{companyPlace} where companyId = #{companyId}")
    void  updateCompanyById(@Param("companyId")String companyId, @Param("companyName")String companyName, @Param("companyPassword")String companyPassword, @Param("companyEmail")String companyEmail, @Param("companySize")String companySize, @Param("companyIntro")String companyIntro, @Param("companyPlace")String companyPlace);

}
