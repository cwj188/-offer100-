package edu.nchu.offer.offer100company.service.impl;

import edu.nchu.offer.offer100company.dao.CompanyMapper;
import edu.nchu.offer.offer100company.service.CompanyService;
import edu.nchu.offer.offer100company.entity.Company;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class CompanyServiceImpl implements CompanyService {
    @Autowired
    private CompanyMapper companyMapper;

    @Override
    public void addCompany(String companyId, String companyName, String companyPassword, String companyEmail, String companySize, String companyIntro, String companyPlace){
        this.companyMapper.insertCompany(companyId, companyName, companyPassword, companyEmail, companySize, companyIntro, companyPlace);
    }

    @Override
    public Company findCompanyById(String companyId){
        return companyMapper.selectCompanyById(companyId);
    }

    @Override
    public void modifyCompany(String companyId, String companyName, String companyPassword, String companyEmail, String companySize, String companyIntro, String companyPlace){
        this.companyMapper.updateCompanyById(companyId, companyName, companyPassword, companyEmail, companySize, companyIntro, companyPlace);
    }
}
