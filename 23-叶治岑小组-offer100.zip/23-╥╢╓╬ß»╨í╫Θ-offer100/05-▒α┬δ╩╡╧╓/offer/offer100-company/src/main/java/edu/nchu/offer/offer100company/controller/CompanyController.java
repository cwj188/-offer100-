package edu.nchu.offer.offer100company.controller;

import edu.nchu.offer.offer100company.entity.Company;
import edu.nchu.offer.offer100company.service.impl.CompanyServiceImpl;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@Controller
public class CompanyController {

    @Autowired
    private CompanyServiceImpl companyService;

    @GetMapping("/")
    public String CompanyLogin(){
        return "CompanyLogin";
    }

    @GetMapping("/CompanyLogin")
    public String Company(){
        return "CompanyLogin";
    }


    @PostMapping("/success")
    public String success(HttpServletRequest request, HttpServletResponse response, String CompanyID, String password){
        Company company = companyService.findCompanyById(CompanyID);
        if(company.getCompanyPassword().equals(password)){
            request.getSession().setAttribute("companyId",CompanyID);
            return "success";
        }
        else {

        }
        return "CompanyLogin";
    }

    @GetMapping("/companyRegister")
    public String register(){
        return "companyRegister";
    }

    @PostMapping("/companyRegister")
    public String companyRegister(String companyId, String companyName, String companyPassword, String companyEmail, String companySize, String companyIntro, String companyPlace){
        this.companyService.addCompany(companyId, companyName, companyPassword, companyEmail, companySize, companyIntro, companyPlace);
        return "registerSuccess";
    }

    @GetMapping("/registerSuccess")
    public String registerJump(){
        return "registerSuccess";
    }

    @PostMapping("/companyInfo")
    public String companyInfo(Model model, HttpServletRequest request, HttpServletResponse response, String CompanyID) throws ServletException,IOException {
        String companyId = new String(request.getSession().getAttribute("companyId").toString().getBytes("ISO-8859-1"),"UTF-8");
        Company companyInfo = companyService.findCompanyById(companyId);
        model.addAttribute("companyInfo", companyInfo);
        return "companyInfo";
    }

    @GetMapping("/companyUpdate")
    public String update(Model model, HttpServletRequest request, HttpServletResponse response) throws ServletException,IOException {
        String companyId = new String(request.getSession().getAttribute("companyId").toString().getBytes("ISO-8859-1"),"UTF-8");
        Company companyInfo = companyService.findCompanyById(companyId);
        model.addAttribute("companyInfo", companyInfo);
        return "companyUpdate";
    }

    @PostMapping("/companyUpdate")
    public String companyUpdate(HttpServletRequest request, String companyName, String companyPassword, String companyEmail, String companySize, String companyIntro, String companyPlace) throws ServletException,IOException{
        String companyId = new String(request.getSession().getAttribute("companyId").toString().getBytes("ISO-8859-1"),"UTF-8");
        this.companyService.modifyCompany(companyId, companyName, companyPassword, companyEmail, companySize, companyIntro, companyPlace);
        return "companyInfo";
    }

    /*@GetMapping("/positionRelease")
    public String positionRelease(){
        return "positionRelease";
    }*/

    @GetMapping("/test")
    public String test(){
        return "test";
    }

}
