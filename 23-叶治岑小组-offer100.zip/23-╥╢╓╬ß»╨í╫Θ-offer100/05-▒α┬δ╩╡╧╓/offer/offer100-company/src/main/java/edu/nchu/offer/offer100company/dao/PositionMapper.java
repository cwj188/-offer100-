package edu.nchu.offer.offer100company.dao;

import edu.nchu.offer.offer100company.entity.Position;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface PositionMapper {

    @Select("select * from positioninfo")
    public List<Position> selectAllPosition();

    @Select("select * from positioninfo where positionId = #{positionId}")
    public Position selectPositionById(@Param("positionId") String positionId);

    @Insert("insert into positioninfo(positionId,positionName,positionType,salary,positionIntro,companyName)values(#{positionId},#{positionName},#{positionType},#{salary},#{positionIntro},#{companyName})")
    void insertPosition(@Param("positionId") int positionId, @Param("positionName") String positionName, @Param("positionType") String positionType, @Param("salary") String salary, @Param("positionIntro") String positionIntro, @Param("companyName") String companyName);

}
