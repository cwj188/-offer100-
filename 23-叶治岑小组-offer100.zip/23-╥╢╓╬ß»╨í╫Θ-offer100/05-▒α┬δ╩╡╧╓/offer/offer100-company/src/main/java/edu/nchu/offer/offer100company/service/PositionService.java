package edu.nchu.offer.offer100company.service;

import edu.nchu.offer.offer100company.entity.Position;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface PositionService {
    List<Position> findAllPosition();
    Position findPositionById(String positionId);
    void addPosition(int positionId,String positionName,String positionType,String salary,String positionIntro,String companyName);
}
