package edu.nchu.offer.offer100company.service.impl;

import edu.nchu.offer.offer100company.dao.PositionMapper;
import edu.nchu.offer.offer100company.entity.Position;
import edu.nchu.offer.offer100company.service.PositionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class PositionServiceImpl implements PositionService {

    @Autowired
    private PositionMapper positionMapper;

    @Override
    public List<Position> findAllPosition(){
        return positionMapper.selectAllPosition();
    }

    @Override
    public Position findPositionById(String positionId){
        return positionMapper.selectPositionById(positionId);
    }

    @Override
    public void addPosition(int positionId, String postionName, String positionType, String salary, String positionIntro, String companyName){
        this.positionMapper.insertPosition(positionId, postionName, positionType, salary, positionIntro, companyName);
    }

}
