package edu.nchu.offer.offer100company.service;

import edu.nchu.offer.offer100company.entity.Company;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CompanyService {
    void addCompany(String companyId, String companyName, String companyPassword, String companyEmail, String companySize, String companyIntro, String companyPlace);
    Company findCompanyById(String companyId);
    void modifyCompany(String companyId, String companyName, String companyPassword, String companyEmail, String companySize, String companyIntro, String companyPlace);
}
